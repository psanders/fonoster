## Sip I/O Business Specific Modules

This repo include the following modules:

- Fonoster Resources Plugin (fn_resources)

