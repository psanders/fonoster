/**
 * @author Pedro Sanders
 * @since v1
 */
load('mod/vendor/fn_resources/utils.js')
load('mod/resources/status.js')

var AgentsAPI = (() => {
    const self = this
    const rUtil = ResUtil.getInstance()
    const resourcePath = 'config/agents.yml'
    const schemaPath = 'mod/resources/schemas/agents_schema.json'

    self.getAgents = filter => rUtil.getObjs('agents', filter)

    self.getAgent = (domainUri, username) => {
        try {
            const filter = '?domainUri=' + domainUri + '&filter=spec.credentials.username==\'' + username + '\''
            const result = rUtil.getWithAuth('/agents' + filter)

            if (result.code && result.code != 200) {
                return {
                    status: result.code,
                    message: result.message
                }
            }

            if (!isEmpty(result)) {
                return {
                    status: Status.OK,
                    message: Status.message[Status.OK].value,
                    obj: result[0]
                }
            }
        } catch(e) {
            return {
                status: Status.BAD_REQUEST,
                message: e.getMessage()
            }
        }

        return {
            status: Status.NOT_FOUND,
            message: Status.message[Status.NOT_FOUND].value
        }
    }

    self.agentExist = (domainUri, username) => {
        const result = self.getAgent(domainUri, username)
        if (result.status == Status.OK) return true
        return false
    }

    self.createAgent = () => {
        return {
            status: Status.NOT_SUPPORTED,
            message: Status.message[Status.NOT_SUPPORTED].value
        }
    }

    self.updateAgent = () => {
        return {
            status: Status.NOT_SUPPORTED,
            message: Status.message[Status.NOT_SUPPORTED].value,
        }
    }

    self.deleteAgents = () => {
        return {
            status: Status.NOT_SUPPORTED,
            message: Status.message[Status.NOT_SUPPORTED].value,
        }
    }

    self.createFromJSONObj = () => {
        return {
            status: Status.NOT_SUPPORTED,
            message: Status.message[Status.NOT_SUPPORTED].value
        }
    }

    self.updateFromJSONObj = () => {
        return {
            status: Status.NOT_SUPPORTED,
            message: Status.message[Status.NOT_SUPPORTED].value
        }
    }

    function _getInstance() {
        return self
    }

    return {
        getInstance: _getInstance
    }
})()