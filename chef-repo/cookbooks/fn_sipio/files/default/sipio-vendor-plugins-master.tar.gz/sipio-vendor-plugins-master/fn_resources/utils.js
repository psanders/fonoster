/**
 * @author Pedro Sanders
 * @since v1
 */
import getConfig from 'core/config_util'
import { Status } from 'resources/status'
import isEmpty from 'utils/obj_util'

const Unirest = Packages.com.mashape.unirest.http.Unirest

export default class ResourcesUtil {

    constructor() {
        this.config = getConfig()
    }

    getWithAuth(path) {
        const config = this.config
        const r = Unirest.get(config.resources.baseUrl + path)
            .basicAuth(config.resources.credentials.username, config.resources.credentials.secret).asJson()
        return JSON.parse(r.getBody())
    }

    postWithAuth(path) {
        const config = this.config
        const r = Unirest.post(config.resources.baseUrl + path)
            .basicAuth(config.resources.credentials.username, config.resources.credentials.secret).asJson()
        return JSON.parse(r.getBody())
    }

    getObjs (resource, f) {
        const config = this.config
        let filter = '*'

        if (!isEmpty(f)) {
            filter = f
        }

        try {
            const encodeFilter = java.net.URLEncoder.encode(filter)
            const result = this.getWithAuth('/' + resource + '?filter=' + encodeFilter)

            if (result.status && result.status != 200) {
                return {
                    status: result.status,
                    message: result.message
                }
            }

            if (!isEmpty(result)) {
                return {
                    status: Status.OK,
                    message: Status.message[Status.OK].value,
                    obj: result
                }
            }
        } catch(e) {
            e.printStackTrace()

            return {
                status: Status.BAD_REQUEST,
                message: e.getMessage()
            }
        }
    }
}