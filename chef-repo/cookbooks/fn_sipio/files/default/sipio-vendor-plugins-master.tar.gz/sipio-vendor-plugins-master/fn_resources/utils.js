/**
 * @author Pedro Sanders
 * @since v1
 */
var ResUtil = (() => {
    const self = this

    self.getWithAuth = path => {
        const Unirest = Packages.com.mashape.unirest.http.Unirest
        const resourcesAPI = new ResourcesUtil().getJson('config/config.yml').resources
        const r = Unirest.get(resourcesAPI.baseUrl + path)
            .basicAuth(resourcesAPI.credentials.username, resourcesAPI.credentials.secret).asJson()
        return JSON.parse(r.getBody())
    }

    self.postWithAuth = path => {
        const Unirest = Packages.com.mashape.unirest.http.Unirest
        const resourcesAPI = new ResourcesUtil().getJson('config/config.yml').resources
        const r = Unirest.post(resourcesAPI.baseUrl + path)
            .basicAuth(resourcesAPI.credentials.username, resourcesAPI.credentials.secret).asJson()
        return JSON.parse(r.getBody())
    }

    self.getObjs = (resource, filter) => {
        try {
            const result = this.getWithAuth('/' + resource + '?filter=' + filter)

            if (result.code && result.code != 200) {
                return {
                    status: result.code,
                    message: result.message
                }
            }

            if (!isEmpty(result)) {
                return {
                    status: Status.OK,
                    message: Status.message[Status.OK].value,
                    obj: result
                }
            }
        } catch(e) {
            return {
                status: Status.BAD_REQUEST,
                message: e.getMessage()
            }
        }

        return {
            status: Status.NOT_FOUND,
            message: Status.message[Status.NOT_FOUND].value
        }
    }

    function _getInstance() {
        return self
    }

    return {
        getInstance: _getInstance
    }
})()