## Fonoster Resources Plugin

**Installation**

```
cd sip.io/mod
mkdir vendor
cd vendor
git clone https://github.com/fonoster/sipio-vendor-plugins/fn_resources
```

**Setup**

Add plugin's specific configuration to `config/config.yaml`

```
resources:
  baseUrl: http://localhost:8080/v1/admin
  credentials:
    username: admin
    secret: 308a002ab539471394a06ce710bc96c2
```

...and overwrite module in 'mod/core/main.js'

```
...
//load('mod/resources/agents_api.js')
//load('mod/resources/domains_api.js')
load('mod/vendor/fn_resources/agents_api.js')
load('mod/vendor/fn_resources/domains_api.js')
...
```
