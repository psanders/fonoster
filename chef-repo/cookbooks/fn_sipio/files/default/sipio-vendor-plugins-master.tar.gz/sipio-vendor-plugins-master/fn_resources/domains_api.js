/**
 * @author Pedro Sanders
 * @since v1
 */
load('mod/resources/status.js')
load('mod/utils/obj_util.js')
// Vendor specific stuff
load('mod/vendor/fn_resources/agents_api.js')
load('mod/vendor/fn_resources/utils.js')

var DomainsAPI = (() => {
    const self = this
    const sipFactory = Packages.javax.sip.SipFactory.getInstance()
    const addressFactory = sipFactory.createAddressFactory()
    const rUtil = ResUtil.getInstance()

    self.getDomains = filter => rUtil.getObjs('domains', filter)

    self.getDomain = domainUri => {
        try {
            const result = rUtil.getWithAuth('/domains/' + domainUri)

            if (result.code && result.code != 200) {
                return {
                    status: result.code,
                    message: result.message
                }
            }

            if (!isEmpty(result)) {
                return {
                    status: Status.OK,
                    message: Status.message[Status.OK].value,
                    obj: result
                }
            }
        } catch(e) {
            return {
                status: Status.BAD_REQUEST,
                message: e.getMessage()
            }
        }

        return {
            status: Status.NOT_FOUND,
            message: Status.message[Status.NOT_FOUND].value
        }
    }

    self.getRouteForAOR = (addressOfRecord) => {
        let result = self.getDomains()

        if (result.status == Status.OK) {
            const domains = result.obj

            for (var domain of domains) {
                if (domain.spec.context.egressPolicy == undefined) continue

                // Get DID and GW info
                result = DIDsAPI.getInstance().getDID(domain.spec.context.egressPolicy.didRef)
                if (result.status != Status.OK) break
                const did = result.obj
                result = GatewaysAPI.getInstance().getGateway(did.metadata.gwRef)
                if (result.status != Status.OK) break
                const gw = result.obj
                const gwHost = gw.spec.regService.host
                const gwUsername = gw.spec.regService.credentials.username
                const egressRule = domain.spec.context.egressPolicy.rule

                const pattern = 'sip:' + egressRule + '@' + domain.spec.context.domainUri

                if (!new RegExp(pattern).test(addressOfRecord.toString())) continue

                const contactURI = addressFactory.createSipURI(addressOfRecord.getUser(), gwHost)
                contactURI.setSecure(addressOfRecord.isSecure())

                const route = {
                    isLinkAOR: false,
                    thruGW: true,
                    rule: egressRule,
                    gwUsername: gwUsername,
                    gwHost: gwHost,
                    did: did.spec.location.telUrl,
                    contactURI: contactURI
                }

                return {
                    status: Status.OK,
                    message: Status.message[Status.OK].value,
                    obj: route
                }
            }
        }

        return {
            status: Status.NOT_FOUND,
            message: Status.message[Status.NOT_FOUND].value
        }
    }

    self.domainExist = (domainUri) => {
        const result = self.getDomain(domainUri)
        if (result.status == Status.OK) return true
        return false
    }

    self.createDomain = () => {
        return {
            status: Status.NOT_SUPPORTED,
            message: Status.message[Status.NOT_SUPPORTED].value
        }
    }

    self.updateDomain = () => {
        return {
            status: Status.NOT_SUPPORTED,
            message: Status.message[Status.NOT_SUPPORTED].value,
        }
    }

    self.deleteDomains = () => {
        return {
            status: Status.NOT_SUPPORTED,
            message: Status.message[Status.NOT_SUPPORTED].value,
        }
    }

    self.domainHasUser = (domainUri, username) => {
        const result = AgentsAPI.getInstance().getAgent(domainUri, username)
        if (result.status == Status.OK) return true
        return false
    }

    self.createFromJSONObj = () => {
        return {
            status: Status.NOT_SUPPORTED,
            message: Status.message[Status.NOT_SUPPORTED].value
        }
    }

    self.updateFromJSONObj = () => {
        return {
            status: Status.NOT_SUPPORTED,
            message: Status.message[Status.NOT_SUPPORTED].value
        }
    }

    function _getInstance() {
        return self
    }

    return {
        getInstance: _getInstance
    }
})()