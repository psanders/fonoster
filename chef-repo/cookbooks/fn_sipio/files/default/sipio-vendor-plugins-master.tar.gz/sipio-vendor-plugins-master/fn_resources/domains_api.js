/**
 * @author Pedro Sanders
 * @since v1
 */
import ResourcesUtil from 'vendor/fn_resources/utils'
import AgentsAPI from 'vendor/fn_resources/agents_api'
import GatewaysAPI from 'resources/gateways_api'
import DIDsAPI from 'resources/dids_api'
import { Status } from 'resources/status'
import isEmpty from 'utils/obj_util'

const sipFactory = Packages.javax.sip.SipFactory.getInstance()
const addressFactory = sipFactory.createAddressFactory()

export default class DomainsAPI {

    constructor() {
        this.rUtil = new ResourcesUtil()
        this.gatewaysAPI = new GatewaysAPI()
        this.didsAPI = new DIDsAPI()
        this.agentsAPI = new AgentsAPI()
    }

    getDomains(filter) {
        return this.rUtil.getObjs('domains', filter)
    }

    getDomain(domainUri) {
        try {
            const result = this.rUtil.getWithAuth('/domains/' + domainUri)

            if (result.status && result.status != 200) {
                return {
                    status: result.status,
                    message: result.message
                }
            }

            if (!isEmpty(result)) {
                return {
                    status: Status.OK,
                    message: Status.message[Status.OK].value,
                    obj: result
                }
            }
        } catch(e) {
            return {
                status: Status.BAD_REQUEST,
                message: e.getMessage()
            }
        }

        return {
            status: Status.NOT_FOUND,
            message: Status.message[Status.NOT_FOUND].value
        }
    }

    getRouteForAOR(addressOfRecord) {
        if (!(addressOfRecord instanceof Packages.javax.sip.address.SipURI)) throw 'AOR must be instance of javax.sip.address.SipURI'

        const didsAPI = this.didsAPI
        const gatewaysAPI = this.gatewaysAPI
        const addressFactory = this.addressFactory

        let result = this.getDomains()
        let route

        if (result.status == Status.OK) {
            const domains = result.obj

            domains.forEach(domain => {
                if (!isEmpty(domain.spec.context.egressPolicy)) {
                    // Get DID and GW info
                    result = didsAPI.getDID(domain.spec.context.egressPolicy.didRef)
                    if (result.status == Status.OK) {
                        const did = result.obj
                        result = gatewaysAPI.getGateway(did.metadata.gwRef)
                        if (result.status == Status.OK) {
                            const gw = result.obj
                            const gwHost = gw.spec.regService.host
                            const gwUsername = gw.spec.regService.credentials.username
                            const gwRef = gw.metadata.ref
                            const egressRule = domain.spec.context.egressPolicy.rule
                            const pattern = 'sip:' + egressRule + '@' + domain.spec.context.domainUri

                            if (new RegExp(pattern).test(addressOfRecord.toString())) {
                                const contactURI = addressFactory.createSipURI(addressOfRecord.getUser(), gwHost)
                                contactURI.setSecure(addressOfRecord.isSecure())

                                route = {
                                    isLinkAOR: false,
                                    thruGW: true,
                                    rule: egressRule,
                                    gwUsername: gwUsername,
                                    gwRef: gwRef,
                                    gwHost: gwHost,
                                    did: did.spec.location.telUrl.split(':')[1],
                                    contactURI: contactURI
                                }
                            }
                        }
                    }
                }
            })
        }

        if(route) {
            return {
                status: Status.OK,
                message: Status.message[Status.OK].value,
                obj: route
            }
        }

        return {
            status: Status.NOT_FOUND,
            message: Status.message[Status.NOT_FOUND].value
        }
    }

    domainExist(domainUri) {
        const result = this.getDomain(domainUri)
        if (result.status == Status.OK) return true
        return false
    }

    createDomain() {
        return {
            status: Status.NOT_SUPPORTED,
            message: Status.message[Status.NOT_SUPPORTED].value
        }
    }

    updateDomain() {
        return {
            status: Status.NOT_SUPPORTED,
            message: Status.message[Status.NOT_SUPPORTED].value,
        }
    }

    deleteDomains() {
        return {
            status: Status.NOT_SUPPORTED,
            message: Status.message[Status.NOT_SUPPORTED].value,
        }
    }

    domainHasUser(domainUri, username) {
        const result = this.agentsApi.getAgent(domainUri, username)
        if (result.status == Status.OK) return true
        return false
    }

    createFromJSONObj() {
        return {
            status: Status.NOT_SUPPORTED,
            message: Status.message[Status.NOT_SUPPORTED].value
        }
    }

    updateFromJSONObj() {
        return {
            status: Status.NOT_SUPPORTED,
            message: Status.message[Status.NOT_SUPPORTED].value
        }
    }
}